#include <stdio.h>

#define ESPADA 1
#define BASTO 2
#define ORO 3
#define COPA 4

const int JUGADOR1 = 1;
const int JUGADOR2 = 2;

const char AURORA = 'A';
const char MALEFICA = 'M';

typedef struct carta {
	int numero;
	int palo;
} carta_t;

typedef struct cartas_jugador {
	carta_t carta1;
	carta_t carta2;
	carta_t carta3;
} cartas_jugador_t;

typedef struct mano_juego {
	cartas_jugador_t cartas_jugador1;
	cartas_jugador_t cartas_jugador2;
} mano_juego_t;

// Pre: El palo de la carta es ESPADA o BASTO o ORO o COPA y el número está entre 1 y 12
// Pos: Imprime por pantalla el número y palo de la carta
void imprimir_carta(carta_t carta) {
	printf("%i de ", carta.numero);

	switch (carta.palo) {
		case ESPADA:
			printf("Espada\n");
			break;
		case BASTO:
			printf("Basto\n");
			break;
		case ORO:
			printf("Oro\n");
			break;
		case COPA:
			printf("Copa\n");
			break;
	}
}

// Pre: carta_jugador1 es distinta de carta_jugador2
// Pos: Devuelve JUGADOR1 si carta_jugador1 es mejor que carta_jugador2.
//		Sino, JUGADOR2
int ganador_ronda_individual(carta_t carta_jugador1, carta_t carta_jugador2) {
	int ganador = -1;

	if (carta_jugador1.numero < carta_jugador2.numero) {
		ganador = JUGADOR1;
	} else if (carta_jugador2.numero < carta_jugador1.numero) {
		ganador = JUGADOR2;
	} else if (carta_jugador1.palo < carta_jugador2.palo) {
		ganador = JUGADOR1;
	} else if (carta_jugador2.palo < carta_jugador1.palo) {
		ganador = JUGADOR2;
	}

	return ganador;
}

// Pre: Todas las cartas tienen número entre 1 y 12, y palo ESPADA o BASTO o ORO o COPA
// Pos: Devuelve AURORA si gana el jugador 1, sino MALEFICA.
char jugador_ganador(mano_juego_t mano) {
	int ganador_ronda1 = ganador_ronda_individual(mano.cartas_jugador1.carta1,
													mano.cartas_jugador2.carta1);
	int ganador_ronda2 = ganador_ronda_individual(mano.cartas_jugador1.carta2,
													mano.cartas_jugador2.carta2);
	int ganador_ronda3 = ganador_ronda_individual(mano.cartas_jugador1.carta3,
													mano.cartas_jugador2.carta3);

	int ganador;
	if (ganador_ronda1 == ganador_ronda2 ||
		ganador_ronda1 == ganador_ronda3) {
		ganador = ganador_ronda1;
	} else {
		ganador = ganador_ronda2;
	}

	if (ganador == JUGADOR1) {
		return AURORA;
	}

	return MALEFICA;
}

int main() {
	carta_t carta1, carta2, carta3;
	carta_t carta4, carta5, carta6;
	
	carta1.numero = 1;
	carta1.palo = BASTO;
	carta2.numero = 6;
	carta2.palo = ESPADA;
	carta3.numero = 2;
	carta3.palo = ORO;

	carta4.numero = 4;
	carta4.palo = COPA;
	carta5.numero = 6;
	carta5.palo = COPA;
	carta6.numero = 1;
	carta6.palo = ESPADA;

	cartas_jugador_t cartas_jugador1, cartas_jugador2;

	cartas_jugador1.carta1 = carta1;
	cartas_jugador1.carta2 = carta2;
	cartas_jugador1.carta3 = carta3;

	cartas_jugador2.carta1 = carta4;
	cartas_jugador2.carta2 = carta5;
	cartas_jugador2.carta3 = carta6;

	mano_juego_t mano_juego;

	mano_juego.cartas_jugador1 = cartas_jugador1;
	mano_juego.cartas_jugador2 = cartas_jugador2;

	char ganador = jugador_ganador(mano_juego);
	printf("Ganó %c\n", ganador);

	return 0;
}