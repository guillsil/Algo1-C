#include <stdio.h>
#include "disney.h"

const int ID_DORMILON = 1;
const int ID_GRUNION = 2;
const int ID_TONTIN = 3;
const char DORMILON = 'D';
const char GRUNION = 'G';
const char TONTIN = 'T';
const char ERROR = 'E';


char enano(int id_enano){
	if(id_enano == ID_DORMILON){
		return DORMILON;
	} else if(id_enano == ID_GRUNION){
		return GRUNION;
	}else if(id_enano == ID_TONTIN){
		return TONTIN;
	}else{
		return ERROR;
	}
}

void asignar_enanito(){

	int id_consulta = 3;
	char enanito_fiestero = enano(id_consulta);
	printf("Te toco ser %c\n",enanito_fiestero);

}

/*
 * Pre: -
 * Post: la letra estara entre a e y
 */
void pedir_letra_lilo(char* letra) {
    printf("Lilo ingresa una letra: ");
    scanf(" %c", letra);
    while((*letra < 'a') || (*letra > 'y')) {
        printf("Lilo no seas mala! ingresa una letra entra la a y la y: ");
        scanf(" %c", letra);
    }
}

/*
 * Pre: la letra_lilo esta entre a e y
 * Post: letra_stich sera la siguiente a letra_lilo
 */
void pedir_letra_stitch(char* letra_stitch, char letra_lilo) {
    printf("Stitch ingresa la siguiente letra: ");
    scanf(" %c", letra_stitch);
    while(*letra_stitch != (letra_lilo+1)) {
        printf("No! esa no es la letra siguiente, intenta de nuevo: ");
        scanf(" %c", letra_stitch);
    }
}

// Imprime las letras de lilo y stitch
void imprimir_letras(char letra_lilo, char letra_stitch) {
    printf("La letra de Lilo es: %c\n", letra_lilo);
    printf("La letra de Stitch es: %c\n", letra_stitch);
}


void enseniar_stitch(){
    char letra_lilo;
    char letra_stitch;
    pedir_letra_lilo(&letra_lilo);
    pedir_letra_stitch(&letra_stitch, letra_lilo);
    imprimir_letras(letra_lilo, letra_stitch);
}
