#ifndef __DISNEY_H___
#define __DISNEY_H___


// pre y post
void asignar_enanito();


// pre y post
void enseniar_stitch();


#endif //__DISNEY_H___