#include <stdio.h>
#include "disney.h"

int main(){

    asignar_enanito();
    enseniar_stitch();

    return 0;
}