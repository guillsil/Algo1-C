#include <stdio.h>
#include "truco_trucho.h"

// Pre: carta_jugador1 es distinta de carta_jugador2
// Pos: Devuelve JUGADOR1 si carta_jugador1 es mejor que carta_jugador2.
//		Sino, JUGADOR2
int ganador_ronda_individual(carta_t carta_jugador1, carta_t carta_jugador2) {
	int ganador = -1;

	if (carta_jugador1.numero < carta_jugador2.numero) {
		ganador = JUGADOR1;
	} else if (carta_jugador2.numero < carta_jugador1.numero) {
		ganador = JUGADOR2;
	} else {
		if (carta_jugador1.palo == ESPADA) {
			ganador = JUGADOR1;
		} else if (carta_jugador2.palo == ESPADA) {
			ganador = JUGADOR2;
		} else if (carta_jugador1.palo == BASTO) {
			ganador = JUGADOR1;
		} else if (carta_jugador2.palo == BASTO) {
			ganador = JUGADOR2;
		} else if (carta_jugador1.palo == ORO) {
			ganador = JUGADOR1;
		} else if (carta_jugador2.palo == ORO) {
			ganador = JUGADOR2;
		}
	}

	return ganador;
}

int jugador_ganador(mano_juego_t mano) {
	int ganador_ronda1 = ganador_ronda_individual(mano.cartas_jugador1.carta1,
													mano.cartas_jugador2.carta1);
	int ganador_ronda2 = ganador_ronda_individual(mano.cartas_jugador1.carta2,
													mano.cartas_jugador2.carta2);
	int ganador_ronda3 = ganador_ronda_individual(mano.cartas_jugador1.carta3,
													mano.cartas_jugador2.carta3);

	int ganados_jugador1 = 0;
	int ganados_jugador2 = 0;
	if (ganador_ronda1 == JUGADOR1) {
		ganados_jugador1++;
	} else {
		ganados_jugador2++;
	}

	if (ganador_ronda2 == JUGADOR1) {
		ganados_jugador1++;
	} else {
		ganados_jugador2++;
	}

	if (ganador_ronda3 == JUGADOR1) {
		ganados_jugador1++;
	} else {
		ganados_jugador2++;
	}

	if (ganados_jugador1 > ganados_jugador2) {
		return JUGADOR1;
	} else {
		return JUGADOR2;
	}
}

