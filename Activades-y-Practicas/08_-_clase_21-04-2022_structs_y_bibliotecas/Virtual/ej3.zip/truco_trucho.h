#ifndef __TRUCO_TRUCHO_H__
#define __TRUCO_TRUCHO_H__

static const char ESPADA = 'E';
static const char BASTO = 'B';
static const char ORO = 'O';
static const char COPA = 'C';

static const int JUGADOR1 = 1;
static const int JUGADOR2 = 2;

typedef struct carta {
	int numero;
	char palo;
} carta_t;

typedef struct cartas_jugador {
	carta_t carta1;
	carta_t carta2;
	carta_t carta3;
} cartas_jugador_t;

typedef struct mano_juego {
	cartas_jugador_t cartas_jugador1;
	cartas_jugador_t cartas_jugador2;
} mano_juego_t;

/*
 * Pre: todas las carta_t son validas:
 *      - palo debe ser ORO, ESPADA, BASTO o COPA.
 *      - numero debe estar entre 1 y 12.
 *      - no puede haber dos identicas.
 * Post: devuelve JUGADOR1 si ganan las cartas de mano.cartas_jugador1 
 *              o JUGADOR2 si ganan las cartas de mano.cartas_jugador2
 */
int jugador_ganador(mano_juego_t mano);

#endif /* __TRUCO_TRUCHO_H__ */