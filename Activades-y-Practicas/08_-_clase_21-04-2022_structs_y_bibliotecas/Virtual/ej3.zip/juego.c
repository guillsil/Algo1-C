#include "truco_trucho.h"
#include <stdio.h>

const char AURORA = 'A';
const char MALEFICA = 'M';

int main() {
	carta_t carta1, carta2, carta3;
	carta_t carta4, carta5, carta6;
	
	carta1.numero = 1;
	carta1.palo = BASTO;
	carta2.numero = 6;
	carta2.palo = ESPADA;
	carta3.numero = 2;
	carta3.palo = ORO;

	carta4.numero = 4;
	carta4.palo = COPA;
	carta5.numero = 6;
	carta5.palo = COPA;
	carta6.numero = 1;
	carta6.palo = ESPADA;

	cartas_jugador_t cartas_jugador1, cartas_jugador2;

	cartas_jugador1.carta1 = carta1;
	cartas_jugador1.carta2 = carta2;
	cartas_jugador1.carta3 = carta3;

	cartas_jugador2.carta1 = carta4;
	cartas_jugador2.carta2 = carta5;
	cartas_jugador2.carta3 = carta6;

	mano_juego_t mano_juego;

	mano_juego.cartas_jugador1 = cartas_jugador1;
	mano_juego.cartas_jugador2 = cartas_jugador2;

    char ganador = ' ';
    if(jugador_ganador(mano_juego) == JUGADOR1) {
        ganador = AURORA;
    } else {
        ganador = MALEFICA;
    }

	printf("Ganó %c\n", ganador);

	return 0;
}